/*
 * Descripción: Mostrar números del 100 al 1 con do-while
 * Autor: Javi
 * Fecha: 15/10/25
 */

package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
	
		int numero = 100;
		
		if (numero >= 1)
			do {
            System.out.print(numero + " ");
            numero--;
			} while (numero >= 1);
		
		
	}

}

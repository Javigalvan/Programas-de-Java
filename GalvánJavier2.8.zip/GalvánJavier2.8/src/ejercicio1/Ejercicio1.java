/*
 * Descripción: Mostrar números del 1 al 100 con while
 * Autor: Javi
 * Fecha: 15/10/25
 */

package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		
		int numero = 0;
		
		while (numero <= 100) {
			System.out.print (numero++ + " ");
		}

	}

}
